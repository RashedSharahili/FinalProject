//
//  ItemCollectionViewCell.swift
//  FinalProject
//
//  Created by Rashed Shrahili on 20/02/1444 AH.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    //MARK: - IBOutlet
    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var itemLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
