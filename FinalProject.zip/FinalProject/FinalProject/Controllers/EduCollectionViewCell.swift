//
//  EduCollectionViewCell.swift
//  FinalProject
//
//  Created by Rashed Shrahili on 22/02/1444 AH.
//

import UIKit

class EduCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var eduImageView: UIImageView!
    @IBOutlet weak var eduLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
