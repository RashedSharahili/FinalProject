//
//  educationModel.swift
//  FinalProject
//
//  Created by Rashed Shrahili on 21/02/1444 AH.
//

import UIKit

struct Education {
    
    var edu_id:Int
    var edu_name:String?
    
}
