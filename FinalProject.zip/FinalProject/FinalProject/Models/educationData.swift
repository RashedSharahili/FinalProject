//
//  educationData.swift
//  FinalProject
//
//  Created by Rashed Shrahili on 21/02/1444 AH.
//

import UIKit

var eduactionArr:[Education] = [
    
    Education(edu_id: 1, edu_name: "Know Things"),
    Education(edu_id: 2, edu_name: "Emotion Classification")
]
