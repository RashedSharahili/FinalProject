//
//  entertainmentModel.swift
//  FinalProject
//
//  Created by Rashed Shrahili on 21/02/1444 AH.
//

import UIKit

struct EnterTainment {
    
    var e_id:Int
    var e_name:String?
    
}
