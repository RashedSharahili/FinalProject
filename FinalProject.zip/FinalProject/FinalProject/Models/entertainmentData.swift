//
//  entertainmentData.swift
//  FinalProject
//
//  Created by Rashed Shrahili on 21/02/1444 AH.
//

import UIKit

var entertainmentArr:[EnterTainment] = [
    
    EnterTainment(e_id: 1, e_name: "Tajma"),
    EnterTainment(e_id: 2, e_name: "Funny Glasses"),
    EnterTainment(e_id: 3, e_name: "SolarSystem"),
    EnterTainment(e_id: 4, e_name: "Bowling")
]
