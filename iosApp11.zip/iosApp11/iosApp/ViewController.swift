//
//  ViewController.swift
//  iosApp
//
//  Created by mac book on 21/02/1444 AH.
//
import UIKit
import RealityKit

class ViewController: UIViewController {
    
    @IBOutlet var arView: ARView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SolarSystem.loadSceneAsync { [weak self] result in
            switch result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let solarSystem):
                self?.arView.scene.anchors.append(solarSystem)
            }
        }
    }
}
